#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QSerialPort>
#include <QSerialPortInfo>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    qDebug() <<"App Iniciada "<<contador;

    ttl =new QSerialPort(this);

    foreach (const QSerialPortInfo &serialport, QSerialPortInfo::availablePorts()) {
        QString nombrePuerto=serialport.portName();
        qDebug()<<nombrePuerto;
        ui->comboPUERTOS->addItem(nombrePuerto);


    }

}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_ENCENDIDO_clicked()
{
       QByteArray datos;
       datos.append(0x74);
       ttl->write(datos);
       qDebug()<<datos;
}

void Widget::on_APAGADO_clicked()
{

    QByteArray datos;
    datos.append(0x75);
    ttl->write(datos);
    qDebug()<<datos;
}
void Widget::on_DERECHA_clicked()
{   QByteArray datos;
    datos.append(0x33);
    ttl->write(datos);
    qDebug()<<datos;

}
void Widget::on_IZQUIERDA_clicked()
{
    QByteArray datos;
    datos.append(0x34);
    ttl->write(datos);
    qDebug()<<datos;
}


void Widget::on_botonAbrir_clicked()
{
    QString portname=ui->comboPUERTOS->currentText();

    if(ui->botonAbrir->text()=="Abrir"){
        ttl->close();
        ttl->setPortName(portname);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->open(QSerialPort::ReadWrite);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setFlowControl(QSerialPort::NoFlowControl);
        ttl->setParity(QSerialPort::NoParity);
        connect(ttl,SIGNAL(readyRead()),this,SLOT(leerread()));

        ui->botonAbrir->setText("Cerrar");
    }else{
        ttl->close();
        disconnect(ttl,SIGNAL(readyRead()),this,SLOT(leerread()));
        ui->botonAbrir->setText("Abrir");


    }

}

void Widget::leerread()
{
    QByteArray buffer=ttl->readAll();
    qDebug()<<buffer;
    //hasta aca sirve melo
    uint8_t BIT1_R =buffer.at(2);
    uint8_t BIT2_R =buffer.at(3);
    uint RPM = (BIT2_R << 8) | BIT1_R;
    qDebug()<<RPM;
    ui->label_2->setText(QString::number(RPM));

}



