#ifndef WIDGET_H
#define WIDGET_H
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_BotonsetRPM_clicked();
    void on_ADD_clicked();
    void on_botonAbrir_clicked();
    void leerread();
    void on_DERECHA_clicked();
    void on_IZQUIERDA_clicked();

    void on_ENCENDIDO_clicked();

    void on_APAGADO_clicked();

    void on_APAGAR_clicked();

    void on_ENCENDER_clicked();

private:
    Ui::Widget *ui;
    int contador=500;
    QSerialPort*ttl=nullptr;
};
#endif // WIDGET_H
