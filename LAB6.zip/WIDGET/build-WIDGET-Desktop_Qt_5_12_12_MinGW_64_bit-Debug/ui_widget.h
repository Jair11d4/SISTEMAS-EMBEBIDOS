/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QHBoxLayout *horizontalLayout;
    QPushButton *ENCENDIDO;
    QPushButton *APAGADO;
    QPushButton *DERECHA;
    QPushButton *IZQUIERDA;
    QSplitter *splitter;
    QLabel *label_3;
    QLabel *label_2;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_4;
    QLabel *PUERTOS;
    QComboBox *comboPUERTOS;
    QPushButton *botonAbrir;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(600, 300);
        Widget->setMinimumSize(QSize(600, 300));
        layoutWidget = new QWidget(Widget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 30, 359, 31));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        ENCENDIDO = new QPushButton(layoutWidget);
        ENCENDIDO->setObjectName(QString::fromUtf8("ENCENDIDO"));

        horizontalLayout->addWidget(ENCENDIDO);

        APAGADO = new QPushButton(layoutWidget);
        APAGADO->setObjectName(QString::fromUtf8("APAGADO"));

        horizontalLayout->addWidget(APAGADO);

        DERECHA = new QPushButton(layoutWidget);
        DERECHA->setObjectName(QString::fromUtf8("DERECHA"));

        horizontalLayout->addWidget(DERECHA);

        IZQUIERDA = new QPushButton(layoutWidget);
        IZQUIERDA->setObjectName(QString::fromUtf8("IZQUIERDA"));

        horizontalLayout->addWidget(IZQUIERDA);


        horizontalLayout_2->addLayout(horizontalLayout);


        horizontalLayout_3->addLayout(horizontalLayout_2);

        splitter = new QSplitter(Widget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(30, 100, 301, 64));
        splitter->setOrientation(Qt::Horizontal);
        label_3 = new QLabel(splitter);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter->addWidget(label_3);
        label_2 = new QLabel(splitter);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QFont font;
        font.setPointSize(40);
        label_2->setFont(font);
        label_2->setAutoFillBackground(false);
        splitter->addWidget(label_2);
        layoutWidget1 = new QWidget(Widget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(30, 70, 248, 27));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        PUERTOS = new QLabel(layoutWidget1);
        PUERTOS->setObjectName(QString::fromUtf8("PUERTOS"));
        QFont font1;
        font1.setPointSize(11);
        PUERTOS->setFont(font1);

        horizontalLayout_4->addWidget(PUERTOS);

        comboPUERTOS = new QComboBox(layoutWidget1);
        comboPUERTOS->setObjectName(QString::fromUtf8("comboPUERTOS"));

        horizontalLayout_4->addWidget(comboPUERTOS);

        botonAbrir = new QPushButton(layoutWidget1);
        botonAbrir->setObjectName(QString::fromUtf8("botonAbrir"));

        horizontalLayout_4->addWidget(botonAbrir);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        ENCENDIDO->setText(QApplication::translate("Widget", "Encendido", nullptr));
        APAGADO->setText(QApplication::translate("Widget", "Apagado", nullptr));
        DERECHA->setText(QApplication::translate("Widget", "Giro Derecha", nullptr));
        IZQUIERDA->setText(QApplication::translate("Widget", "Giro Izquierda", nullptr));
        label_3->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:36pt;\">RPM</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("Widget", "0", nullptr));
        PUERTOS->setText(QApplication::translate("Widget", "PUERTOS", nullptr));
        botonAbrir->setText(QApplication::translate("Widget", "Abrir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
