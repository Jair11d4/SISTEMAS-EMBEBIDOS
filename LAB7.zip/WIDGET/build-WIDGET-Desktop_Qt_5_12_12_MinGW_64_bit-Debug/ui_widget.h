/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QSplitter *splitter;
    QLabel *label_3;
    QLabel *label_2;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_4;
    QLabel *PUERTOS;
    QComboBox *comboPUERTOS;
    QPushButton *botonAbrir;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QPushButton *ENCENDIDO;
    QPushButton *APAGADO;
    QLabel *label;
    QLabel *RPMMAX;
    QLabel *label_5;
    QLabel *TIEMPOMAX;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *FIJARRPM;
    QLineEdit *RPMENV;
    QSplitter *splitter_2;
    QLabel *label_4;
    QLabel *seg;
    QCustomPlot *customPlot;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1155, 681);
        Widget->setMinimumSize(QSize(600, 300));
        splitter = new QSplitter(Widget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(30, 100, 211, 31));
        splitter->setOrientation(Qt::Horizontal);
        label_3 = new QLabel(splitter);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter->addWidget(label_3);
        label_2 = new QLabel(splitter);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QFont font;
        font.setPointSize(16);
        label_2->setFont(font);
        label_2->setAutoFillBackground(false);
        splitter->addWidget(label_2);
        layoutWidget = new QWidget(Widget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 70, 248, 27));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        PUERTOS = new QLabel(layoutWidget);
        PUERTOS->setObjectName(QString::fromUtf8("PUERTOS"));
        QFont font1;
        font1.setPointSize(11);
        PUERTOS->setFont(font1);

        horizontalLayout_4->addWidget(PUERTOS);

        comboPUERTOS = new QComboBox(layoutWidget);
        comboPUERTOS->setObjectName(QString::fromUtf8("comboPUERTOS"));

        horizontalLayout_4->addWidget(comboPUERTOS);

        botonAbrir = new QPushButton(layoutWidget);
        botonAbrir->setObjectName(QString::fromUtf8("botonAbrir"));

        horizontalLayout_4->addWidget(botonAbrir);

        layoutWidget1 = new QWidget(Widget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(30, 30, 251, 27));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        ENCENDIDO = new QPushButton(layoutWidget1);
        ENCENDIDO->setObjectName(QString::fromUtf8("ENCENDIDO"));

        horizontalLayout->addWidget(ENCENDIDO);

        APAGADO = new QPushButton(layoutWidget1);
        APAGADO->setObjectName(QString::fromUtf8("APAGADO"));

        horizontalLayout->addWidget(APAGADO);

        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(31, 161, 161, 25));
        label->setFont(font);
        RPMMAX = new QLabel(Widget);
        RPMMAX->setObjectName(QString::fromUtf8("RPMMAX"));
        RPMMAX->setGeometry(QRect(190, 160, 91, 25));
        RPMMAX->setFont(font);
        RPMMAX->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_5 = new QLabel(Widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 190, 181, 25));
        label_5->setFont(font);
        TIEMPOMAX = new QLabel(Widget);
        TIEMPOMAX->setObjectName(QString::fromUtf8("TIEMPOMAX"));
        TIEMPOMAX->setGeometry(QRect(190, 190, 91, 25));
        TIEMPOMAX->setFont(font);
        TIEMPOMAX->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        layoutWidget2 = new QWidget(Widget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(290, 30, 196, 27));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        FIJARRPM = new QPushButton(layoutWidget2);
        FIJARRPM->setObjectName(QString::fromUtf8("FIJARRPM"));

        horizontalLayout_2->addWidget(FIJARRPM);

        RPMENV = new QLineEdit(layoutWidget2);
        RPMENV->setObjectName(QString::fromUtf8("RPMENV"));

        horizontalLayout_2->addWidget(RPMENV);

        splitter_2 = new QSplitter(Widget);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setGeometry(QRect(30, 130, 211, 25));
        splitter_2->setOrientation(Qt::Horizontal);
        label_4 = new QLabel(splitter_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font);
        splitter_2->addWidget(label_4);
        seg = new QLabel(splitter_2);
        seg->setObjectName(QString::fromUtf8("seg"));
        seg->setFont(font);
        seg->setAutoFillBackground(false);
        splitter_2->addWidget(seg);
        customPlot = new QCustomPlot(Widget);
        customPlot->setObjectName(QString::fromUtf8("customPlot"));
        customPlot->setGeometry(QRect(310, 130, 811, 491));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        label_3->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:16pt;\">RPM</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:16pt;\">0</span></p></body></html>", nullptr));
        PUERTOS->setText(QApplication::translate("Widget", "PUERTOS", nullptr));
        botonAbrir->setText(QApplication::translate("Widget", "Abrir", nullptr));
        ENCENDIDO->setText(QApplication::translate("Widget", "Encendido", nullptr));
        APAGADO->setText(QApplication::translate("Widget", "Apagado", nullptr));
        label->setText(QApplication::translate("Widget", "RPM MAX", nullptr));
        RPMMAX->setText(QApplication::translate("Widget", "0", nullptr));
        label_5->setText(QApplication::translate("Widget", "SEG MAX", nullptr));
        TIEMPOMAX->setText(QApplication::translate("Widget", "0", nullptr));
        FIJARRPM->setText(QApplication::translate("Widget", "Setear", nullptr));
        label_4->setText(QApplication::translate("Widget", "<html><head/><body><p>SEG</p></body></html>", nullptr));
        seg->setText(QApplication::translate("Widget", "0", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
