#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QSerialPort>
#include <QSerialPortInfo>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    qDebug() <<"App Iniciada ";

    ttl =new QSerialPort(this);

    foreach (const QSerialPortInfo &serialport, QSerialPortInfo::availablePorts()) {
        QString nombrePuerto=serialport.portName();
        qDebug()<<nombrePuerto;
        ui->comboPUERTOS->addItem(nombrePuerto);
    }
    Widget:setupPlot();

}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_ENCENDIDO_clicked()
{
       QByteArray datos;
       datos.append(0x74);
       ttl->write(datos);
       bandera1=0;
       RPMant=0;
}
void Widget::setupPlot(){

    x.resize(301);
    y.resize(301);
    for (int i=0; i<301; ++i)
    {
      x[i] = (double)i;
      y[i] = (double)2;
    }

    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->graph(0)->setData(x, y);
    ui->customPlot->graph(0)->setName("RPM");
    ui->customPlot->plotLayout()->insertRow(0);
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPTextElement(ui->customPlot, "Velocidad - Motor DC", QFont("sans", 12, QFont::Bold)));


    ui->customPlot->legend->setVisible(true);
    QFont legendFont = font();  // start out with MainWindow's font..
    legendFont.setPointSize(9); // and make a bit smaller for legend
    ui->customPlot->legend->setFont(legendFont);
    ui->customPlot->legend->setBrush(QBrush(QColor(255,255,255,230)));
    // by default, the legend is in the inset layout of the main axis rect. So this is how we access it to change legend placement:
    //ui->customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignBottom|Qt::AlignRight);

    ui->customPlot->xAxis->setLabel("Time Relative");
    ui->customPlot->yAxis->setLabel("RPM.");
    ui->customPlot->xAxis->setRange(0, 300);
    ui->customPlot->yAxis->setRange(0, 5000);
    ui->customPlot->replot();
}

void Widget::makeplot(double rpm){

    for (int i=0; i<300; ++i)
    {
      y[i] = y[i + 1];
    }
    y[300] = rpm;
    ui->customPlot->graph(0)->setData(x, y);
    ui->customPlot->replot();
}
void Widget::on_APAGADO_clicked()
{

    QByteArray datos;
    datos.append(0x75);
    ttl->write(datos);
    qDebug()<<datos;
    bandera1=0;
    RPMant=0;
}
void Widget::on_botonAbrir_clicked()
{
    QString portname=ui->comboPUERTOS->currentText();

    if(ui->botonAbrir->text()=="Abrir"){
        ttl->close();
        ttl->setPortName(portname);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->open(QSerialPort::ReadWrite);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setFlowControl(QSerialPort::NoFlowControl);
        ttl->setParity(QSerialPort::NoParity);
        connect(ttl,SIGNAL(readyRead()),this,SLOT(leerread()));

        ui->botonAbrir->setText("Cerrar");
    }else{
        ttl->close();
        disconnect(ttl,SIGNAL(readyRead()),this,SLOT(leerread()));
        ui->botonAbrir->setText("Abrir");


    }

}

void Widget::leerread()
{
    QByteArray buffer=ttl->readAll();
    uint8_t BIT1_R =buffer.at(2);
    uint8_t BIT2_R =buffer.at(3);
    RPM = (BIT2_R << 8) | BIT1_R;
    TIEMPO=buffer.at(4);
    ui->label_2->setText(QString::number(RPM));
    ui->seg->setText(QString::number(TIEMPO));
    if(RPM>RPMant && bandera1==1){
        RPMant=RPM;
        TIEMPOMAX=TIEMPO;
        contador=0;
    }else{
        contador++;
    }
    if(contador>2 && bandera1==1){
        ui->RPMMAX->setText(QString::number(RPMant));
        ui->TIEMPOMAX->setText(QString::number(TIEMPOMAX));
    }
    makeplot(RPM);

}
void Widget::on_FIJARRPM_clicked()
{   int signo=0;
    QString rpm_txt = ui->RPMENV->text();
    enviarrpm = rpm_txt.toInt();
    QByteArray datos;
    datos.append(0x0F);
    if(enviarrpm>0){
        signo=0xff;
    }else if(enviarrpm<0){
        enviarrpm=-enviarrpm;
        signo=0xef;
    }
    int enviar1=enviarrpm & 0xff;
    int enviar2=enviarrpm >> 8;
    datos.append(enviar1);
    datos.append(enviar2);
    datos.append(signo);
    ttl->write(datos);
    bandera1=1;
    RPMant=0;
}
