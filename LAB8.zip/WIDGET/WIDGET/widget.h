#ifndef WIDGET_H
#define WIDGET_H
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QWidget>
#include <QVector>
#include <QSerialPort>
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void makeplot(double rpm);
    void on_BotonsetRPM_clicked();
    void on_ADD_clicked();
    void on_botonAbrir_clicked();
    void leerread();
    void on_DERECHA_clicked();
    void on_IZQUIERDA_clicked();

    void on_ENCENDIDO_clicked();

    void on_APAGADO_clicked();

    void on_APAGAR_clicked();

    void on_ENCENDER_clicked();

    void on_FIJARRPM_clicked();

    void on_prueba_clicked();

private:
    Ui::Widget *ui;
    int enviarrpm;
    uint RPM;
    uint RPMant=0;
    uint TIEMPO=0;
    uint TIEMPOMAX=0;
    int contador=0;
    int bandera1=0;
    QSerialPort*ttl=nullptr;
    void setupPlot();
    //double x[100],y[100];
    QVector<double> x;
    QVector<double> y;
    QVector<double> z;
    QVector<double> w;
};
#endif // WIDGET_H
