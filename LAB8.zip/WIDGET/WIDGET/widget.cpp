#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QSerialPort>
#include <QSerialPortInfo>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->progressBar->setRange(0,100);
    ui->progressBar_2->setRange(0,100);
    ui->progressBar_3->setRange(0,100);
    ui->progressBar_4->setRange(0,100);
    ui->progressBar->setValue(0);
    ui->progressBar_2->setValue(0);
    ui->progressBar_3->setValue(0);
    ui->progressBar_4->setValue(0);
    qDebug() <<"App Iniciada ";

    ttl =new QSerialPort(this);

    foreach (const QSerialPortInfo &serialport, QSerialPortInfo::availablePorts()) {
        QString nombrePuerto=serialport.portName();
        qDebug()<<nombrePuerto;
        ui->comboPUERTOS->addItem(nombrePuerto);
    }

}

Widget::~Widget()
{
    delete ui;
}
void Widget::on_botonAbrir_clicked()
{
    QString portname=ui->comboPUERTOS->currentText();

    if(ui->botonAbrir->text()=="Abrir"){
        ttl->close();
        ttl->setPortName(portname);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->open(QSerialPort::ReadWrite);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setFlowControl(QSerialPort::NoFlowControl);
        ttl->setParity(QSerialPort::NoParity);
        connect(ttl,SIGNAL(readyRead()),this,SLOT(leerread()));

        ui->botonAbrir->setText("Cerrar");
    }else{
        ttl->close();
        disconnect(ttl,SIGNAL(readyRead()),this,SLOT(leerread()));
        ui->botonAbrir->setText("Abrir");


    }

}

void Widget::leerread()
{
    QByteArray buffer=ttl->readAll();
    uint8_t S1=buffer.at(0);
    uint8_t S2=buffer.at(1);
    uint8_t S3=buffer.at(2);
    uint8_t S4=buffer.at(3);
    ui->progressBar->setValue(S1);
    ui->progressBar_2->setValue(S2);
    ui->progressBar_3->setValue(S3);
    ui->progressBar_4->setValue(S4);
    ui->label_2->setText(QString::number(S1));
    ui->RPMMAX->setText(QString::number(S2));
    ui->seg->setText(QString::number(S3));
    ui->TIEMPOMAX->setText(QString::number(S4));


}
