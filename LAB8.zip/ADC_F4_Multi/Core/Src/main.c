/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void ADC_Init_Custom(){

	  hadc1.Instance = ADC1;
	  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
	  hadc1.Init.ScanConvMode = ENABLE;
	  hadc1.Init.ContinuousConvMode = ENABLE;
	  hadc1.Init.DiscontinuousConvMode = DISABLE;
	  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	  hadc1.Init.NbrOfConversion = 1;
	  hadc1.Init.DMAContinuousRequests = DISABLE;
	  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	  if (HAL_ADC_Init(&hadc1) != HAL_OK)
	  {
	    Error_Handler();
	  }

}

uint32_t ADC_SelectCH(uint32_t Channel){

	ADC_ChannelConfTypeDef sConfig = {0};
	uint32_t result;

	  sConfig.Channel = Channel;
	  sConfig.Rank = 1;
	  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		Error_Handler();
	  }

	HAL_ADC_Start(&hadc1);
	HAL_ADC_PollForConversion(&hadc1, 100);
	result= HAL_ADC_GetValue(&hadc1);
	HAL_ADC_Stop(&hadc1);
	return result;
}
uint32_t S1=0;
uint32_t S2=0;
uint32_t S3=0;
uint32_t S4=0;
int tiempo=0;
uint8_t datos[8];
char texto2[128];
float adc_volt(int adc);
float voltS1=0;
float voltS2=0;
float voltS3=0;
float voltS4=0;
float voltablaS1[20]={3.127545788,3.104175824,3.08967033,3.050181258,2.816573668,2.22981685,1.872014652,1.353040293,1.077435897,0.836135813,0.757509158,0.63985348,0.547179487,0.493156103,0.43032967,0.408571429,0.36989011,0.319120879,0.272380952,0.245787546};
int tablamm[20]={5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100};
float distanciaS1(float voltaje);
uint8_t distanciaS1val=0;
float voltablaS2[20]={3.129157509,3.107399267,2.97040293,2.596371859,1.695710751,1.278901099,1.004908425,0.693040293,0.543956044,0.540730966,0.481098901,0.419047619,0.361025641,0.320879442,0.29010989,0.270769231,0.245787546,0.219194139,0.199047619,0.182124542};
float distanciaS2(float voltaje);
uint8_t distanciaS2val=0;
float voltablaS3[20]={3.099340659,3.086446886,2.95025641,2.661631444,1.82813997,1.463443223,0.960586081,0.68014652,0.606007326,0.474304311,0.418241758,0.338461538,0.283663004,0.248351969,0.215164835,0.195018315,0.173260073,0.143443223,0.12007326,0.107985348};
float distanciaS3(float voltaje);
uint8_t distanciaS3val=0;
float voltablaS4[20]={3.115457875,3.112234432,3.086150366,3.053402808,2.650386727,2.173406593,1.236190476,1.138681319,1.025860806,0.775697887,0.667252747,0.571355311,0.502051282,0.438545356,0.381172161,0.342490842,0.314285714,0.278827839,0.232893773,0.22};
float distanciaS4(float voltaje);
uint8_t distanciaS4val=0;
float S1prom=0;
float S2prom=0;
float S3prom=0;
float S4prom=0;
int contador=0;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  HAL_TIM_Base_Start(&htim1);
  ADC_Init_Custom();

  while (1)
  {
	  int bandera=0;
	  tiempo=__HAL_TIM_GET_COUNTER(&htim1);
	  if(tiempo>=0 && tiempo<20){
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,1);
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0);
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,0);
		  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,0);
		  S1 = ADC_SelectCH(ADC_CHANNEL_4);

		  bandera=0;
	  }else if(tiempo>=20 && tiempo<40){
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,0);
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1);
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,0);
		  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,0);
		  S2 = ADC_SelectCH(ADC_CHANNEL_1);
		  bandera=0;

	  }else if(tiempo>=40 && tiempo<60){
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,0);
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0);
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,1);
		  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,0);
		  S3 = ADC_SelectCH(ADC_CHANNEL_2);

		  bandera=0;
	  }else if(tiempo>=60 && tiempo<80){
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,0);
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0);
		  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,0);
		  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,1);
		  S4 = ADC_SelectCH(ADC_CHANNEL_3);

		  bandera=0;
	  }else{
		  tiempo=0;
		  bandera=1;
	  }
	  if(contador<10 && bandera==1){
		  S1prom=S1prom+S1;
		  S2prom=S2prom+S2;
		  S3prom=S3prom+S3;
		  S4prom=S4prom+S4;
		  contador++;
	  }else if(contador>=10 && bandera==1){
		  S1prom=S1prom/10;
		  S2prom=S2prom/10;
		  S3prom=S3prom/10;
		  S4prom=S4prom/10;
		  voltS1=adc_volt(S1prom);
		  voltS2=adc_volt(S2prom);
		  voltS3=adc_volt(S3prom);
		  voltS4=adc_volt(S4prom);
		  distanciaS1val=distanciaS1(voltS1);
		  distanciaS2val=distanciaS2(voltS2);
		  distanciaS3val=distanciaS3(voltS3);
		  distanciaS4val=distanciaS4(voltS4);
		  contador=0;
		  datos[0]=distanciaS1val;
		  datos[1]=distanciaS2val;
		  datos[2]=distanciaS3val;
		  datos[3]=distanciaS4val;
		  CDC_Transmit_FS(datos,4);
	  }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 4;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = 4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 4800-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB3 PB4 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
float adc_volt(int adc){
	float volt=(adc*3.3)/4095;
	return volt;
}
float distanciaS1(float voltaje){
	for (int i=0;i<20;i++){
		if(voltablaS1[i]>voltaje && voltaje>voltablaS1[i+1]){
			float coordenaday1=voltablaS1[i];
			float coordenaday2=voltablaS1[i+1];
			float coordenadax1=tablamm[i];
			float coordenadax2=tablamm[i+1];
			//calcular pendiente y eso
			float m=(coordenaday2-coordenaday1)/(coordenadax2-coordenadax1);
			float b=coordenaday1-(m*coordenadax1);
			float mm=(voltaje-b)/(m);
			return mm;
		}else if(voltablaS1[19]>voltaje){
			float mm=100;
			return mm;
		}
	}

}
float distanciaS2(float voltaje){
	for (int i=0;i<20;i++){
		if(voltablaS2[i]>voltaje && voltaje>voltablaS2[i+1]){
			float coordenaday1=voltablaS2[i];
			float coordenaday2=voltablaS2[i+1];
			float coordenadax1=tablamm[i];
			float coordenadax2=tablamm[i+1];
			//calcular pendiente y eso
			float m=(coordenaday2-coordenaday1)/(coordenadax2-coordenadax1);
			float b=coordenaday1-(m*coordenadax1);
			float mm=(voltaje-b)/(m);
			return mm;
		}else if(voltablaS2[19]>voltaje){
			float mm=100;
			return mm;
		}
	}
}
float distanciaS3(float voltaje){
	for (int i=0;i<20;i++){
		if(voltablaS3[i]>voltaje && voltaje>voltablaS3[i+1]){
			float coordenaday1=voltablaS3[i];
			float coordenaday2=voltablaS3[i+1];
			float coordenadax1=tablamm[i];
			float coordenadax2=tablamm[i+1];
			//calcular pendiente y eso
			float m=(coordenaday2-coordenaday1)/(coordenadax2-coordenadax1);
			float b=coordenaday1-(m*coordenadax1);
			float mm=(voltaje-b)/(m);
			return mm;
		}else if(voltablaS3[19]>voltaje){
			float mm=100;
			return mm;
		}
	}
}
float distanciaS4(float voltaje){
	for (int i=0;i<20;i++){
		if(voltablaS4[i]>voltaje && voltaje>voltablaS4[i+1]){
			float coordenaday1=voltablaS4[i];
			float coordenaday2=voltablaS4[i+1];
			float coordenadax1=tablamm[i];
			float coordenadax2=tablamm[i+1];
			//calcular pendiente y eso
			float m=(coordenaday2-coordenaday1)/(coordenadax2-coordenadax1);
			float b=coordenaday1-(m*coordenadax1);
			float mm=(voltaje-b)/(m);
			return mm;
		}else if(voltablaS4[19]>voltaje){
				float mm=100;
				return mm;
			}
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
